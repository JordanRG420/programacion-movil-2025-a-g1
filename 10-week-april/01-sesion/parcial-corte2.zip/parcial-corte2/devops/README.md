# 📁 devops

## Contiene configuraciones de automatización, despliegue y CI/CD. Aquí suelen ir archivos de Docker, Kubernetes, GitHub Actions, pipelines, etc.

### Ej: Dockerfile, docker-compose.yml, .gitlab-ci.yml, Helm charts, etc.#