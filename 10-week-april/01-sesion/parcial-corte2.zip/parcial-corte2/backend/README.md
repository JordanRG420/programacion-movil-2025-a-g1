# 📁 backend

## Contiene la lógica del servidor, servicios, APIs y todo lo que ocurre "detrás de escena". Aquí se suele usar tecnologías como Node.js, Java, Python, etc.

### Ej: Controladores, rutas, middleware, servicios, autenticación, etc.