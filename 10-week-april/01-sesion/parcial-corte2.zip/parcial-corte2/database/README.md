# 📁 database

## Almacena todo lo relacionado con la gestión de la base de datos: scripts SQL, modelos, migraciones, seeds, backups y documentación de estructura.

### Ej: Archivos .sql, migraciones con Sequelize, scripts de creación de tablas.