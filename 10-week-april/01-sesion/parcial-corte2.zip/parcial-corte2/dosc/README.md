# 📁 docs

## Carpeta destinada a la documentación del proyecto. Aquí puedes incluir manuales, diagramas, especificaciones técnicas, guías de instalación, etc.

### Ej: README.md, diagramas UML, documentación de APIs, PDF de requerimientos.