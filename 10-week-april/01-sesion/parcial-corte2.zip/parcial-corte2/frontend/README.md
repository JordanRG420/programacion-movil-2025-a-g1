# 📁 frontend

## Incluye el cliente del proyecto, o la interfaz gráfica (UI) con la que interactúan los usuarios. Suele estar construido con React, Angular, Vue, etc.

### Ej: Componentes, rutas del navegador, páginas, estilos, assets.

