import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.example.contactos',
  appName: 'Agenda de Contactos',
  webDir: 'dist',
  server: {
    cleartext: true, // Permite conexiones HTTP no seguras (solo desarrollo)
    allowNavigation: [
      'localhost:9000', // Permite conexión a tu backend Spring Boot
      'http://localhost:9000'
    ]
  },
  plugins: {
    CapacitorHttp: {
      enabled: true // Habilita el plugin HTTP si lo necesitas
    }
  }
};

export default config;