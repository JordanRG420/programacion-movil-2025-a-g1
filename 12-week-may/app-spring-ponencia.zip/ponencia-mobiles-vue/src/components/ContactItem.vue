<template>
  <div class="contact-card">
    <div class="contact-header">
      <h3>{{ contact.name }}</h3>
      <!-- Cambiado de nombre a name -->
      <div class="contact-actions">
        <button @click="$emit('edit', contact.id)" class="edit-button">
          Editar
        </button>
        <button @click="$emit('delete', contact.id)" class="delete-button">
          Eliminar
        </button>
      </div>
    </div>

    <div class="contact-details">
      <p><span class="detail-label">Email:</span> {{ contact.email }}</p>
      <!-- Cambiado de correo a email -->
      <p>
        <span class="detail-label">Teléfono:</span> {{ contact.phone_number }}
      </p>
      <!-- Cambiado de telefono a phone_number -->
      <p v-if="contact.company">
        <!-- Cambiado de empresa a company -->
        <span class="detail-label">Empresa:</span> {{ contact.company }}
      </p>
    </div>
  </div>
</template>

<script setup lang="ts">
import type { Contact } from "vite-env.d";

defineProps<{
  contact: Contact;
}>();

defineEmits<{
  (e: "edit", id: number): void;
  (e: "delete", id: number): void;
}>();
</script>

<style scoped>
.contact-card {
  width: 80%;
  background-color: var(--card-background);
  border-radius: 8px;
  padding: 1.5rem;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s, box-shadow 0.3s;
}

.contact-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
}

.contact-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
  border-bottom: 1px solid #eee;
  padding-bottom: 0.5rem;
}

.contact-header h3 {
  margin: 0;
  color: var(--primary-color);
}

.contact-actions {
  display: flex;
  gap: 0.5rem;
}

.edit-button,
.delete-button {
  padding: 0.25rem 0.5rem;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 0.85rem;
}

.edit-button {
  background-color: var(--secondary-color);
  color: white;
}

.delete-button {
  background-color: var(--error-color);
  color: white;
}

.contact-details p {
  margin: 0.5rem 0;
}

.detail-label {
  font-weight: bold;
  color: var(--primary-color);
}
</style>
