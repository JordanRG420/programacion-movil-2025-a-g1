<template>
  <div class="contact-list">
    <div class="search-container">
      <input
        v-model="searchTerm"
        type="text"
        placeholder="Buscar contactos..."
        class="search-input"
        @input="handleSearch"
      />
    </div>

    <div v-if="store.loading" class="loading-container">
      <p>Cargando contactos...</p>
    </div>

    <div v-else-if="store.error" class="error-container">
      <p>Error: {{ store.error }}</p>
      <button @click="reloadContacts" class="retry-button">Reintentar</button>
    </div>

    <div v-else-if="filteredContacts.length === 0" class="empty-container">
      <p v-if="searchTerm">
        No se encontraron resultados para "{{ searchTerm }}"
        <button @click="clearSearch" class="clear-button">Limpiar búsqueda</button>
      </p>
      <p v-else>No hay contactos disponibles</p>
      <router-link to="/add" class="add-button">
        {{ searchTerm ? "Limpiar búsqueda" : "Agregar primer contacto" }}
      </router-link>
    </div>

    <div v-else class="contacts-grid">
      <ContactItem
        v-for="contact in filteredContacts"
        :key="contact.id"
        :contact="contact"
        @edit="handleEdit"
        @delete="handleDelete"
      />
    </div>

    <div class="add-button-container">
      <router-link to="/add" class="add-button">+ Nuevo Contacto</router-link>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, ref, onMounted } from "vue";
import { useContactsStore } from "@/stores/contacts";
import ContactItem from "@/components/ContactItem.vue";
import { useRouter } from "vue-router";

const store = useContactsStore();
const router = useRouter();
const searchTerm = ref("");

const reloadContacts = async () => {
  try {
    await store.fetchContacts(true); // Fuerza recarga desde backend
  } catch (error) {
    console.error("Error al recargar contactos:", error);
  }
};

// Carga inicial de contactos
onMounted(() => {
  reloadContacts();
});

const clearSearch = () => {
  searchTerm.value = "";
};

const handleSearch = () => {
  // Puedes agregar debounce aquí si necesitas
  console.log("Buscando:", searchTerm.value);
};

const filteredContacts = computed(() => {
  if (!store.contacts || store.contacts.length === 0) return [];
  
  const term = searchTerm.value.toLowerCase().trim();
  if (!term) return store.contacts;

  return store.contacts.filter(contact => 
    (contact.name?.toLowerCase().includes(term)) ||
    (contact.email?.toLowerCase().includes(term)) ||
    (contact.phone_number?.toLowerCase().includes(term)) ||
    (contact.company?.toLowerCase().includes(term))
  );
});

const handleEdit = (id: number) => {
  router.push(`/edit/${id}`);
};

const handleDelete = async (id: number) => {
  if (confirm("¿Estás seguro de eliminar este contacto?")) {
    try {
      await store.deleteContact(id);
    } catch (error) {
      console.error("Error al eliminar contacto:", error);
      alert("No se pudo eliminar el contacto. Por favor, intente nuevamente.");
    }
  }
};
</script>

<style scoped>
/* Tus estilos actuales se mantienen igual */
.clear-button {
  margin-left: 10px;
  padding: 0.25rem 0.5rem;
  background-color: #f0f0f0;
  border: 1px solid #ddd;
  border-radius: 4px;
  cursor: pointer;
}
.search-container {
  margin-bottom: 2rem;
  width: 85%;
}

.search-input {
  width: 100%;
  padding: 0.75rem;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 1rem;
}
.clear-button:hover {
  background-color: #e0e0e0;
}
.add-button-container {
  text-align: center;
  margin-top: 2rem;
}

.add-button {
  display: inline-block;
  padding: 0.75rem 1.5rem;
  background-color: var(--primary-color);
  color: white;
  text-decoration: none;
  border-radius: 4px;
  transition: background-color 0.3s;
}

.add-button:hover {
  background-color: #1a2a3a;
}
</style>