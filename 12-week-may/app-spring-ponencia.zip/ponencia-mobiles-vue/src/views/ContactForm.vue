<template>
  <div class="contact-form-container">
    <h2 v-if="contactId">Editar Contacto</h2>
    <h2 v-else>Nuevo Contacto</h2>

    <!-- Mostrar mensaje de error si existe -->
    <div v-if="error" class="error-message">
      {{ error }}
    </div>

    <form @submit.prevent="handleSubmit" class="contact-form">
      <div class="form-group">
        <label for="name">Nombre:</label>
        <input
          id="name"
          v-model="form.name"
          type="text"
          required
          class="form-input"
          :disabled="loading"
        />
      </div>

      <div class="form-group">
        <label for="email">Correo electrónico:</label>
        <input
          id="email"
          v-model="form.email"
          type="email"
          required
          class="form-input"
          :disabled="loading"
        />
      </div>

      <div class="form-group">
        <label for="phone_number">Teléfono:</label>
        <input
          id="phone_number"
          v-model="form.phone_number"
          type="tel"
          required
          class="form-input"
          :disabled="loading"
        />
      </div>

      <div class="form-group">
        <label for="company">Empresa (opcional):</label>
        <input
          id="company"
          v-model="form.company"
          type="text"
          class="form-input"
          :disabled="loading"
        />
      </div>

      <div class="form-actions">
        <button
          type="button"
          @click="handleCancel"
          class="cancel-button"
          :disabled="loading"
        >
          Cancelar
        </button>
        <button type="submit" class="submit-button" :disabled="loading">
          {{ loading ? "Guardando..." : "Guardar" }}
        </button>
      </div>
    </form>
  </div>
</template>
<script setup lang="ts">
import { ref, onMounted } from "vue";
import { useContactsStore } from "@/stores/contacts";
import { useRouter, useRoute } from "vue-router";
import type { Contact } from "@/stores/contacts"; // Asegúrate de que la ruta sea correcta

const store = useContactsStore();
const router = useRouter();
const route = useRoute();

const contactId = ref<number | null>(null);
const form = ref<Omit<Contact, "id">>({
  name: "",
  email: "",
  phone_number: "", // Usar phone_number en lugar de phone
  company: "",
});

const loading = ref(false);
const error = ref<string | null>(null);

onMounted(() => {
  if (route.params.id) {
    contactId.value = Number(route.params.id);
    loadContactData();
  }
});

const loadContactData = async () => {
  try {
    loading.value = true;
    // Si no está en el store, podrías hacer una petición directa a la API
    const existingContact = store.contacts.find(
      (c) => c.id === contactId.value
    );
    if (existingContact) {
      form.value = {
        name: existingContact.name,
        email: existingContact.email,
        phone_number: existingContact.phone_number,
        company: existingContact.company || "",
      };
    }
  } catch (e) {
    error.value = "Error al cargar el contacto";
    console.error(e);
  } finally {
    loading.value = false;
  }
};

const handleSubmit = async () => {
  try {
    loading.value = true;
    error.value = null;

    if (contactId.value) {
      await store.updateContact(contactId.value, form.value);
    } else {
      await store.saveContact(form.value);
    }

    // Esperar explícitamente a que se complete fetchContacts
    await store.fetchContacts();

    // Redirigir después de confirmar que los datos están actualizados
    router.push("/");
  } catch (e) {
    error.value = "Error al guardar el contacto";
    console.error("Error al guardar contacto:", e);
  } finally {
    loading.value = false;
  }
};

const handleCancel = () => {
  router.push("/");
};
</script>

<style scoped>
.contact-form-container {
  width: 80%; /* Reducir el ancho en móviles */
  max-width: 400px; /* Disminuir el tamaño total */
  background-color: var(--card-background);
  padding: 1.5rem; /* Reducir espacio interno */
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

/* Ajustar los botones en móviles */
.form-actions {
  display: flex;
  flex-direction: column; /* Botones en columna en pantallas pequeñas */
  align-items: center; /* Centrar botones */
  gap: 0.5rem; /* Reducir espacio entre botones */
}

.cancel-button,
.submit-button {
  width: 100%; /* Hacer que ocupen todo el ancho disponible */
  max-width: 200px; /* Evitar que sean demasiado grandes */
}

/* Resto de tus estilos permanecen igual */
.contact-form-container h2 {
  color: var(--primary-color);
  margin-top: 0;
  margin-bottom: 1.5rem;
  text-align: left;
}

.form-group {
  margin-bottom: 1.5rem;
}

.form-group label {
  display: inline-block;
  margin-bottom: 0.5rem;
  font-weight: bold;
  color: var(--primary-color);
}

.form-input {
  width: 80%; /* Ajusta el porcentaje según lo necesites */
  max-width: 300px; /* Evita que sean demasiado largos */
  padding: 0.5rem; /* Reduce el padding para hacerlos más compactos */
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 1rem;
}

.cancel-button {
  background-color: #f0f0f0;
  color: var(--text-color);
}

.cancel-button:hover {
  background-color: #e0e0e0;
}

.submit-button {
  background-color: var(--secondary-color);
  color: white;
}

.submit-button:hover {
  background-color: #379c6f;
}
.error-message {
  color: #ff4444;
  margin-bottom: 1rem;
  text-align: center;
}

/* Añadir estilo para campos deshabilitados */
.form-input:disabled {
  background-color: #f5f5f5;
  cursor: not-allowed;
}

/* Ajustar los botones */
.cancel-button,
.submit-button {
  width: 90%; /* Aumenta el ancho de los botones */
  max-width: 150px; /* Permite un tamaño mayor */
  font-size: 1.2rem; /* Aumenta el tamaño de la fuente */
  padding: 0.75rem; /* Hace los botones más grandes */
}



</style>
