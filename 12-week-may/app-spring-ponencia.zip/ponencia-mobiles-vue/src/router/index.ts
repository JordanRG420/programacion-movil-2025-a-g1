import { createRouter, createWebHistory } from 'vue-router'
import ContactList from '@/views/ContactList.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: ContactList
    },
    {
      path: '/edit/:id',
      name: 'edit',
      component: () => import('@/views/ContactForm.vue'),
      props: true
    },
    {
      path: '/add',
      name: 'add',
      component: () => import('@/views/ContactForm.vue')
    }
  ]
})

export default router