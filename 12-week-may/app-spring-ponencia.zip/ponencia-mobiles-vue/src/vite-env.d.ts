/// <reference types="vite/client" />

// vite-env.d.ts
interface Contact {
  id: number;
  name: string;
  email: string;
  phone_number: string;
  company: string;
  status: boolean;
  createdAt: string;
  updatedAt: string | null;
  deletedAt: string | null;
  createdBy: number;
  updatedBy: number | null;
  deletedBy: number | null;
}

interface ApiResponse {
  status: boolean
  data?: Contact | Contact[]
  message?: string
}

declare module '*.vue' {
  import { DefineComponent } from 'vue'
  const component: DefineComponent<{}, {}, any>
  export default component
}