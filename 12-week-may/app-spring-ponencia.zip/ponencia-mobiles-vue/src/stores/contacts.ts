// src/stores/contacts.ts
import { defineStore } from 'pinia';
import api from '@/services/api';
 

interface Contact {
  id: number;
  name: string;
  email: string;
  phone_number: string;
  company: string;
  status: boolean;
  createdAt: string;
  updatedAt: string | null;
  deletedAt: string | null;
  createdBy: number;
  updatedBy: number | null;
  deletedBy: number | null;
}

export const useContactsStore = defineStore('contacts', {
  state: () => ({
    contacts: [] as Contact[],
    loading: false,
    error: null as string | null,
  }),
  
  actions: {
    async fetchContacts(force = false) {
      try {
        if (this.contacts.length === 0 || force) {
          this.loading = true;
          this.error = null;
          const response = await api.get<Contact[]>('/contact'); // Cambiado para esperar array directo
          
          // Asignamos la respuesta del backend directamente
          this.contacts = response.data;
          
          console.log("Contactos cargados desde backend:", this.contacts);
        }
      } catch (error) {
        this.error = 'Error al cargar contactos';
        console.error("Error al cargar contactos:", error);
        throw error; // Propaga el error para manejo en componentes
      } finally {
        this.loading = false;
      }
    },
    
    async saveContact(contact: Omit<Contact, 'id'>) {
      try {
        const payload = {
          ...contact,
          status: true
        };
        
        const response = await api.post<Contact>('/contact', payload);
        
        // Actualizamos la lista local con el nuevo contacto
        this.contacts = [...this.contacts, response.data];
        
        return response;
      } catch (error) {
        console.error('Error guardando contacto:', error);
        throw error;
      }
    },
    
    async updateContact(id: number, contact: Partial<Contact>) {
      try {
        const payload = {
          ...contact,
          status: true
        };
        
        const response = await api.put<Contact>(`/contact/${id}`, payload);
        
        // Actualizamos el contacto en la lista local
        this.contacts = this.contacts.map(c => 
          c.id === id ? { ...c, ...response.data } : c
        );
        
        return response;
      } catch (error) {
        console.error('Error actualizando contacto:', error);
        throw error;
      }
    },
    
    async deleteContact(id: number) {
      try {
        await api.delete(`/contact/${id}`);
        
        // Eliminamos el contacto de la lista local
        this.contacts = this.contacts.filter(c => c.id !== id);
      } catch (error) {
        console.error('Error al eliminar contacto:', error);
        throw error;
      }
    }
  },
});