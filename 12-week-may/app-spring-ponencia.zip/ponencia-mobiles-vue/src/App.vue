<template>
  <div class="app-container">
    <header class="app-header">
      <h1>Agenda de Contactos</h1>
      <nav>
        <router-link to="/">Inicio</router-link>
        <router-link to="/add">Nuevo Contacto</router-link>
      </nav>
    </header>

    <main class="app-main">
      <router-view v-slot="{ Component }">
        <transition name="fade" mode="out-in">
          <component :is="Component" />
        </transition>
      </router-view>
    </main>

    <footer class="app-footer">
      <p>&copy; {{ new Date().getFullYear() }} Agenda de Contactos</p>
    </footer>
  </div>
</template>

<script setup lang="ts"></script>

<style scoped>
.app-container {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
  max-width: 100vw;
  overflow-x: hidden;
}

.app-header {
  background-color: var(--primary-color);
  color: white;
  padding: 0.75rem 1rem;
  position: sticky;
  top: 0;
  z-index: 100;
}

.app-header h1 {
  font-size: 1.25rem;
  margin: 0;
  text-align: center;
}

.app-header nav {
  display: flex;
  justify-content: center;
  gap: 1.5rem;
  margin-top: 0.75rem;
}

.app-header a {
  color: white;
  text-decoration: none;
  font-size: 0.9rem;
  padding: 0.25rem 0.5rem;
}

.app-header a.router-link-active {
  font-weight: bold;
  background-color: rgba(255, 255, 255, 0.2);
  border-radius: 4px;
}

.app-main {
  flex: 1;
  padding: 1rem;
  width: 100%;
  box-sizing: border-box;
}

.app-footer {
  background-color: var(--primary-color);
  color: white;
  text-align: center;
  padding: 0.75rem;
  font-size: 0.8rem;
}

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.2s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}

@media (min-width: 600px) {
  .app-header h1 {
    font-size: 1.5rem;
  }

  .app-header a {
    font-size: 1rem;
  }

  .app-main {
    padding: 1.5rem;
  }
}

/* Desktop */
@media (min-width: 900px) {
  .app-main {
    max-width: 800px;
    margin: 0 auto;
  }
}
</style>
