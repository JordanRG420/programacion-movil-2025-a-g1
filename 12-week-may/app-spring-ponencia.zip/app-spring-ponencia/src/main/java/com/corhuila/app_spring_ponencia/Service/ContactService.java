package com.corhuila.app_spring_ponencia.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.corhuila.app_spring_ponencia.Entity.Contact;
import com.corhuila.app_spring_ponencia.IRepository.IBaseRepository;
import com.corhuila.app_spring_ponencia.IRepository.IContactRepository;
import com.corhuila.app_spring_ponencia.IService.IContactService;

/**
 * La clase ContactService es un servicio de Spring que extiende de ABaseService
 * y está diseñada para manejar la lógica de negocio relacionada con la entidad
 * Contact.
 * 
 * Esta clase implementa la interfaz IContactService, lo que asegura que cumpla
 * con
 * un contrato específico para las operaciones relacionadas con Contact.
 * 
 * Principales características:
 * 
 * - Utiliza la anotación @Service para que Spring la detecte como un componente
 * de servicio
 * y pueda ser inyectada en otras partes de la aplicación.
 * 
 * - Sobrescribe el método getRepository() de la clase base ABaseService para
 * devolver
 * el repositorio específico de Contact, que es gestionado por la interfaz
 * IContactRepository.
 * 
 * - Utiliza la anotación @Autowired para inyectar automáticamente la
 * dependencia del
 * repositorio IContactRepository, lo que permite interactuar con la base de
 * datos
 * para realizar operaciones CRUD (Crear, Leer, Actualizar, Eliminar) sobre la
 * entidad Contact.
 * 
 * Este diseño sigue el patrón de arquitectura de capas, separando la lógica de
 * negocio
 * (en el servicio) de la lógica de acceso a datos (en el repositorio).
 */
@Service
public class ContactService extends ABaseService<Contact> implements IContactService {

    @Override
    protected IBaseRepository<Contact, Long> getRepository() {
        return repository;
    }

    @Autowired
    private IContactRepository repository;

}
