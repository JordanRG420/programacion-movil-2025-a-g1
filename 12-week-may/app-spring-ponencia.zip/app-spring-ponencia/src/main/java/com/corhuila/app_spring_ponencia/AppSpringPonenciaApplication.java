package com.corhuila.app_spring_ponencia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppSpringPonenciaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppSpringPonenciaApplication.class, args);
	}

}
