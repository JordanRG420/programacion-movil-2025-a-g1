package com.corhuila.app_spring_ponencia.IService;

import com.corhuila.app_spring_ponencia.Entity.Contact;

public interface IContactService extends IBaseService<Contact> {
    // Aquí puedes agregar métodos específicos para la entidad Contact si es
    // necesario
    // Por ejemplo, puedes definir métodos de búsqueda personalizados o consultas
    // específicas.
    // Ejemplo:
    // List<Contact> findByLastName(String lastName);

}
