package com.corhuila.app_spring_ponencia.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Arrays;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

@Configuration
public class AppConfig {
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowedOrigins(Arrays.asList(
                "http://localhost:8100", // Frontend Ionic Vue en desarrollo
                "capacitor://localhost", // Para aplicaciones móviles Ionic
                "http://localhost" // Para emuladores
        ));
        config.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        config.setAllowedHeaders(Arrays.asList("Content-Type", "Authorization", "X-Requested-With", "Accept"));
        config.setAllowCredentials(true);
        config.setMaxAge(3600L);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);
        return source;
    }
}

/*
 * 
 * Explicación:
 * Este archivo configura las reglas de CORS (Cross-Origin Resource Sharing)
 * para la aplicación Spring.
 * CORS es un mecanismo que permite que recursos restringidos en una página web
 * sean solicitados desde otro dominio distinto al que sirvió la página.
 * 
 * 1. `@Configuration`: Marca esta clase como una clase de configuración de
 * Spring, lo que significa que define beans que serán gestionados por el
 * contenedor de Spring.
 * 
 * 2. `@Bean public CorsConfigurationSource corsConfigurationSource()`:
 * - Define un bean que configura las reglas de CORS.
 * - Se crea una instancia de `CorsConfiguration` para especificar las políticas
 * de acceso.
 * 
 * 3. Configuración de `CorsConfiguration`:
 * - `setAllowedOrigins`: Permite solicitudes desde el origen
 * `http://localhost:8100`.
 * - `setAllowedMethods`: Permite los métodos HTTP `GET`, `POST`, `PUT` y
 * `DELETE`.
 * - `setAllowedHeaders`: Permite los encabezados `Content-Type` y
 * `Authorization`.
 * - `setAllowCredentials`: Habilita el uso de credenciales (como cookies o
 * encabezados de autenticación).
 * 
 * 4. `UrlBasedCorsConfigurationSource`:
 * - Asocia las configuraciones de CORS con todas las rutas (`/**`).
 * - Esto significa que las reglas de CORS se aplicarán a todas las solicitudes
 * entrantes.
 * 
 * En resumen, este archivo asegura que las solicitudes desde
 * `http://localhost:8100` puedan interactuar con la API de manera segura,
 * respetando las reglas definidas.
 * 
 */