package com.corhuila.app_spring_ponencia.IRepository;

import org.springframework.stereotype.Repository;

import com.corhuila.app_spring_ponencia.Entity.Contact;

@Repository
public interface IContactRepository extends IBaseRepository<Contact, Long> {
    // Aquí puedes agregar métodos específicos para la entidad Contact si es
    // necesario
    // Por ejemplo, puedes definir métodos de búsqueda personalizados o consultas
    // específicas.
    // Ejemplo:
    // List<Contact> findByLastName(String lastName);

}
